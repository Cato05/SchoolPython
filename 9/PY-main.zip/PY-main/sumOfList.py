list = [1, 2, 4, 10, 24, 56]

end = len(list)
a = 0

for i in range(0, end):
 a += list[i]
 
print(a)