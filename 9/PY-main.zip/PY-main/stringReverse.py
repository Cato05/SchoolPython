a = str(input("Give me a word: "))

end = len(a)

print(a[end::-1])
