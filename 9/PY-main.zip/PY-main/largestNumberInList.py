list = [1, 10, 12, 34, 53, 2, 5, 30]

a = max(list)

print(a)